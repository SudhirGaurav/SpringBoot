package com.sudhir.jpa.hibernate.jpa_and_hibenate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JpaAndHibenateApplication {

	public static void main(String[] args) {
		SpringApplication.run(JpaAndHibenateApplication.class, args);
	}

}
