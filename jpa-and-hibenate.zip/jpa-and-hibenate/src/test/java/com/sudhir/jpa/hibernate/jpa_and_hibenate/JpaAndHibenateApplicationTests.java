package com.sudhir.jpa.hibernate.jpa_and_hibenate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpaAndHibenateApplicationTests {

	@Test
	void contextLoads() {
	}

}
